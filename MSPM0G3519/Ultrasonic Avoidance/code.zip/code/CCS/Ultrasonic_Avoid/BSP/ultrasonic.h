#ifndef __ULTRASONIC_H_
#define __ULTRASONIC_H_

#include "AllHeader.h"

#define SR04_TRIG(x)  ( x ? DL_GPIO_setPins(TRIG_PORT,TRIG_PIN0_PIN) : DL_GPIO_clearPins(TRIG_PORT,TRIG_PIN0_PIN) )
#define SR04_ECHO()   ( ( ( DL_GPIO_readPins(ECHO_PORT,ECHO_PIN1_PIN) & ECHO_PIN1_PIN ) > 0 ) ? 1 : 0 )

void Ultrasonic_Init(void);//超声波初始化   Ultrasonic initialization
float Hcsr04GetLength(void );//获取超声波测距的距离 Get the distance of ultrasonic ranging

#endif
