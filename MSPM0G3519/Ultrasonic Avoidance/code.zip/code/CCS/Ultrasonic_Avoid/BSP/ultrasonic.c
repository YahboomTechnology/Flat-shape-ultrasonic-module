#include "ultrasonic.h"

volatile unsigned int msHcCount = 0;//ms计数    ms count
volatile float distance = 0;

//超声波初始化
//Ultrasonic initialization
void Ultrasonic_Init(void)
{

    SYSCFG_DL_init();
    //清除定时器中断标志
    //Clear the timer interrupt flag
    NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
    //使能定时器中断
    //Enable timer interrupt
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);

}
//打开定时器    Turn on the timer
void Open_Timer(void)
{

    DL_TimerG_setTimerCount(TIMER_0_INST, 0);   // 清除定时器计数   Clear timer count

    msHcCount = 0;

    DL_TimerG_startCounter(TIMER_0_INST);   // 使能定时器   Enable timer
}

//获取定时器定时时间    Get the timer timing
uint32_t Get_TIMER_Count(void)
{
    uint32_t time  = 0;
    time   = msHcCount*1000;                         // 得到us  Get us
    time  += DL_TimerG_getTimerCount(TIMER_0_INST);  // 得到ms  Get ms

    DL_TimerG_setTimerCount(TIMER_0_INST, 0);   // 清除定时器计数   Clear timer count
    delay_ms(1);
    return time ;
}

//关闭定时器    Turn off the timer
void Close_Timer(void)
{
    DL_TimerG_stopCounter(TIMER_0_INST);     // 关闭定时器  Turn off the timer
}

//定时器中断服务函数    Timer interrupt service function
void TIMER_0_INST_IRQHandler(void)
{
    //如果产生了定时器中断  If a timer interrupt occurs
    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST) )
    {
        case DL_TIMERA_IIDX_LOAD:
                msHcCount++;
            break;

        default://其他的定时器中断  Other timer interrupts
            break;
    }
}

//获取测量距离  Get the measured distance
volatile float t = 0;
float Hcsr04GetLength(void)
{
        /*测5次数据计算一次平均值*/
        /*Measure 5 times and calculate the average value*/
        volatile float length = 0;
		t = 0;
        volatile float sum = 0;
        volatile unsigned int  i = 0;

		Close_Timer();

        while(i != 5)
        {
			SR04_TRIG(1);//TRIG引脚拉高信号，发出高电平 TRIG pin pulls up the signal and sends a high level

			delay_us(15);//TRIG引脚发出高电平信号10us以上   TRIG pin sends a high level signal for more than 10us

			SR04_TRIG(0);//TRIG引脚拉低信号，发出低电平 TRIG pin pulls down the signal and sends a low level

			/*Echo发出信号 等待回响信号*/
			/*输入方波后，模块会自动发射8个40KHz的声波，与此同时回波引脚（echo）端的电平会由0变为1；
			（此时应该启动定时器计时）；当超声波返回被模块接收到时，回波引脚端的电平会由1变为0；
			（此时应该停止定时器计数），定时器记下的这个时间即为超声波由发射到返回的总时长；*/

            /*Echo sends a signal and waits for the echo signal*/
            /*After inputting the square wave, the module will automatically emit 8 40KHz sound waves. At the same time, the level of the echo pin (echo) will change from 0 to 1;
            (the timer should be started at this time); when the ultrasonic wave is returned and received by the module, the level of the echo pin will change from 1 to 0;
            (the timer should be stopped at this time), and the time recorded by the timer is the total duration of the ultrasonic wave from emission to return;*/

			while(SR04_ECHO() == 0);//echo等待回响  echo Wait for response

			Open_Timer();   //打开定时器    Turn on the timer

			i++;

			while(SR04_ECHO() > 0);

			Close_Timer();   // 关闭定时器  Turn off the timer

			delay_ms(5);

			t = (float)Get_TIMER_Count();   // 获取时间,分辨率为1us     Acquisition time, resolution is 1us
			length = (float)t / 58.0f;   // cm
			sum += length;
        }
	length = sum/5;//五次平均值 Five-time average
	distance = length;
	return length;
}

